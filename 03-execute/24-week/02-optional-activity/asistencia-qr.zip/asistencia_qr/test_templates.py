from app import app
from flask import render_template

with app.test_request_context('/'):
    try:
        render_template('instructor/sesion.html', fichas=[], sesion_activa=None, metricas={'total_fichas':0, 'total_sesiones':0, 'asistencia_promedio':0, 'sesiones_activas':0})
        print('sesion.html renders fine')
    except Exception as e:
        print('Error in sesion.html:', e)
        
    try:
        render_template('instructor/historial.html', registros=[], total=0, metricas={}, fichas=[], sesiones=[], pagina=1, filtros={})
        print('historial.html renders fine')
    except Exception as e:
        print('Error in historial.html:', e)

    try:
        render_template('aprendiz/historial.html', registros=[], metricas={'asistencias':0, 'faltas':0, 'retardos':0, 'porcentaje':0})
        print('aprendiz/historial.html renders fine')
    except Exception as e:
        print('Error in aprendiz/historial.html:', e)
        
    try:
        render_template('admin/panel.html', usuarios=[], auditoria_log={'registros':[]}, configuracion=[], fichas=[], metricas={})
        print('admin/panel.html renders fine')
    except Exception as e:
        print('Error in admin/panel.html:', e)
