from models.db import ejecutar_consulta

def registrar(usuario_id, ip_origen, accion, resultado, detalle):
    query = """
        INSERT INTO auditoria (usuario_id, ip_origen, accion, resultado, detalle)
        VALUES (%s, %s, %s, %s, %s)
    """
    return ejecutar_consulta(query, (usuario_id, ip_origen, accion, resultado, detalle), commit=True)

def obtener_log(filtros=None, pagina=1, por_pagina=20):
    if filtros is None:
        filtros = {}
        
    query_base = """
        FROM auditoria a
        LEFT JOIN usuarios u ON a.usuario_id = u.id
        WHERE 1=1
    """
    params = []
    
    if 'usuario_id' in filtros:
        query_base += " AND a.usuario_id = %s"
        params.append(filtros['usuario_id'])
    if 'accion' in filtros:
        query_base += " AND a.accion = %s"
        params.append(filtros['accion'])
    if 'resultado' in filtros:
        query_base += " AND a.resultado = %s"
        params.append(filtros['resultado'])
        
    query_count = f"SELECT COUNT(*) as total {query_base}"
    total = ejecutar_consulta(query_count, tuple(params), fetchone=True)['total']
    
    query_data = f"""
        SELECT a.*, u.nombre as usuario_nombre, u.documento as usuario_documento
        {query_base}
        ORDER BY a.created_at DESC
        LIMIT %s OFFSET %s
    """
    offset = (pagina - 1) * por_pagina
    params.extend([por_pagina, offset])
    
    registros = ejecutar_consulta(query_data, tuple(params), fetchall=True)
    
    return {'registros': registros, 'total': total}
