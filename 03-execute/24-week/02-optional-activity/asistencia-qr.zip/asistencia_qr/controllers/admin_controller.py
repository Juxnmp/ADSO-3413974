"""
Controlador de Administración — Gestión de usuarios, auditoría y configuración.
"""
from flask import Blueprint, request, render_template, redirect, url_for, session, jsonify, flash
from controllers.auth_controller import requiere_rol
from models import usuario, auditoria, ficha
from models.dashboard import obtener_metricas_admin
from models.db import ejecutar_consulta
from controllers.seguridad import hash_password, obtener_ip_real

admin_bp = Blueprint('admin', __name__)


@admin_bp.route('/admin/panel')
@requiere_rol('admin')
def panel():
    """Muestra el panel de administración con pestañas: usuarios, auditoría, configuración."""
    usuarios = usuario.obtener_todos()
    logs = auditoria.obtener_log()
    fichas_lista = ficha.obtener_todas()
    metricas = obtener_metricas_admin()
    
    # Obtener configuración
    config = ejecutar_consulta("SELECT * FROM configuracion", fetchall=True) or []
    
    return render_template('admin/panel.html', 
                           usuarios=usuarios, 
                           auditoria_log=logs, 
                           configuracion=config,
                           fichas=fichas_lista,
                           metricas=metricas)


@admin_bp.route('/admin/usuarios/crear', methods=['POST'])
@requiere_rol('admin')
def crear_usuario():
    """Crea un nuevo usuario en el sistema."""
    nombre = request.form.get('nombre')
    documento = request.form.get('documento')
    password = request.form.get('password', 'sena2026')
    rol = request.form.get('rol')
    centro = request.form.get('centro', '')
    
    pwd_hash = hash_password(password)
    usuario.crear(nombre, documento, pwd_hash, rol, centro)
    
    ip = obtener_ip_real(request)
    auditoria.registrar(session['user_id'], ip, 'USUARIO_CREADO', 'exitoso', f'{nombre} ({documento}) — {rol}')
    
    flash('Usuario creado correctamente', 'success')
    return redirect(url_for('admin.panel'))


@admin_bp.route('/admin/usuarios/editar/<int:id>', methods=['POST'])
@requiere_rol('admin')
def editar_usuario(id):
    """Edita los datos de un usuario existente."""
    datos = {
        'nombre': request.form.get('nombre'),
        'documento': request.form.get('documento'),
        'rol': request.form.get('rol'),
        'centro': request.form.get('centro'),
        'estado': request.form.get('estado')
    }
    # Eliminar campos vacíos
    datos = {k: v for k, v in datos.items() if v}
    
    usuario.actualizar(id, datos)
    
    ip = obtener_ip_real(request)
    auditoria.registrar(session['user_id'], ip, 'USUARIO_EDITADO', 'exitoso', f'ID {id}: {datos}')
    
    flash('Usuario actualizado', 'success')
    return redirect(url_for('admin.panel'))


@admin_bp.route('/admin/auditoria')
@requiere_rol('admin')
def api_auditoria():
    """API: Retorna el log de auditoría filtrado."""
    filtros = {}
    if request.args.get('usuario_id'):
        filtros['usuario_id'] = request.args.get('usuario_id')
    if request.args.get('accion'):
        filtros['accion'] = request.args.get('accion')
    
    logs = auditoria.obtener_log(filtros)
    return jsonify(logs)


@admin_bp.route('/admin/config/guardar', methods=['POST'])
@requiere_rol('admin')
def guardar_config():
    """Guarda la configuración del sistema."""
    for clave in request.form:
        if clave != 'csrf_token':
            valor = request.form.get(clave)
            ejecutar_consulta(
                "UPDATE configuracion SET valor = %s WHERE clave = %s",
                (valor, clave), commit=True
            )
    
    ip = obtener_ip_real(request)
    auditoria.registrar(session['user_id'], ip, 'CONFIG_ACTUALIZADA', 'exitoso', 'Configuración del sistema actualizada')
    
    flash('Configuración guardada', 'success')
    return redirect(url_for('admin.panel'))

# ============================================================
#  GESTIÓN DE FICHAS (ADMIN)
# ============================================================

@admin_bp.route('/admin/fichas/crear', methods=['POST'])
@requiere_rol('admin')
def crear_ficha():
    numero = request.form.get('numero')
    programa = request.form.get('programa')
    sede = request.form.get('sede')
    instructor_id = request.form.get('instructor_id')
    
    ficha.crear(numero, programa, sede, instructor_id)
    ip = obtener_ip_real(request)
    auditoria.registrar(session['user_id'], ip, 'FICHA_CREADA', 'exitoso', f'Ficha {numero}')
    flash('Ficha creada exitosamente', 'success')
    return redirect(url_for('admin.panel'))

@admin_bp.route('/admin/fichas/estado', methods=['POST'])
@requiere_rol('admin')
def cambiar_estado_ficha():
    ficha_id = request.form.get('ficha_id')
    nuevo_estado = request.form.get('estado')
    
    datos = {'estado': nuevo_estado}
    if nuevo_estado in ['finalizada', 'archivada']:
        from datetime import date
        datos['fecha_cierre'] = date.today()
        
    ficha.actualizar(ficha_id, datos)
    
    ip = obtener_ip_real(request)
    auditoria.registrar(session['user_id'], ip, 'ESTADO_FICHA_CAMBIADO', 'exitoso', f'Ficha {ficha_id} -> {nuevo_estado}')
    flash(f'Estado de la ficha cambiado a {nuevo_estado}', 'success')
    return redirect(url_for('admin.panel'))

